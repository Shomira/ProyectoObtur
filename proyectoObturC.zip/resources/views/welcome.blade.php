<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Obtur-UTPL</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
         <link rel="stylesheet" href="{{ asset('css/estilos.css')}}">
        <!-- Styles -->   
        <style>
            body {
                font-family: 'Nunito';
            }
        </style>
        <link rel="stylesheet" href="{{ asset('css/estilos.css')}}">
    </head>
    <body class="antialiased">
    <nav class="navbar navbar-expand-lg navbar-light bg-light"  style="background: linear-gradient(to bottom, yellow, white);">
        <div class="container" >
        <!--Menu de NAVEGACION -->
          <div class="row">
          @extends('layouts.app')
            <a class="navbar-brand" href="#">OBTUR-UTPL</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
              <div class="navbar-nav">
                <a class="nav-link active" aria-current="page" href="{{url('welcome')}}">INICIO</a>
                <a class="nav-link" href="{{url('obtur')}}">OBTUR</a>
                <a class="nav-link" href="{{url('informacionTuristica')}}">INFORMACIÓN TURÍSTICA</a>
                <a class="nav-link" href="{{url('datosEstadisticos')}}"tabindex="-1" aria-disabled="true">DATOS ESTADÍSTICOS</a>
                
              </div>
              </div>
            </div>
          </div>
        </div>
    </nav>
  
    @section('content')
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
     integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<div class="container">
<!--inicia el slider-->
   
<div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel" >
  <ol class="carousel-indicators">
    <li data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active"></li>
    <li data-bs-target="#carouselExampleDark" data-bs-slide-to="1"></li>
    <li data-bs-target="#carouselExampleDark" data-bs-slide-to="2"></li>
  </ol>
 
  <div class="carousel-inner">
    <div class="carousel-item active" >
     <img src="{{ asset('imgs/mangahurco131.png')}}" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5 style="color:white;"> Guayacanes</h5>
        <p style="color:white;" >Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
      </div>
    </div>
    <div class="carousel-item" >
    <img src="{{ asset('imgs/img4.jpeg')}}" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5 style="color:white;" >Second slide label</h5>
        <p style="color:white;" >Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      </div>
    </div>
    <div class="carousel-item">
    <img src="{{ asset('imgs/img5P.png')}}" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5style="color:white;" >Third slide label</h5>
        <pstyle="color:white;" >Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleDark" role="button" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleDark" role="button" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </a>
</div>
<h2>Descubre en la Provincia de Loja</h2>
<section class="sitios1" >    
            <img src="{{ asset('imgs/img1Hom.png')}}">
        <h4>Eventos</h4>
</section >
<section class="sitios2" >
            <img src="{{ asset('imgs/img2Hom.png')}}">
        <h4>Plazas</h4>
</section >
<section class="sitios3">
            <img  src="{{ asset('imgs/img3Hom.png')}}">
        <h4>Atractivos</h4>
</section >
<section class="sitios4" >
            <img  src="{{ asset('imgs/img4Hom.png')}}">
        <h4>Parques</h4>
</section>
</div>
  <script>
var myCarousel = document.querySelector('#myCarousel')
var carousel = new bootstrap.Carousel(myCarousel, {
  interval: 2000,
  wrap: false
})
</script>
   
@endsection

    </body>
</html>


