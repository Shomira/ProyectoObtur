


<?php $__env->startSection('content'); ?>
    <section class="portfolioInforTuris">
        <img style="width: 600px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg1.png')); ?>"  alt="">
        <img style="width: 600px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg2.png')); ?>"  alt="">
        <img style="width: 600px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg3.png')); ?>"  alt="">
        <img style="width: 600px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg4.png')); ?>"  alt="">
        <img style="width: 600px; height: 326px; object-fit: cover;"src="<?php echo e(asset('imgs/Itimag5.png')); ?>"  alt="">
        <img style="width: 600px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg6.png')); ?>"  alt="">
        <img style="width: 600px; height: 326px; object-fit: cover;"src="<?php echo e(asset('imgs/Itimg7.png')); ?>"  alt="">
        <img style="width: 600px; height: 326px; object-fit: cover;"src="<?php echo e(asset('imgs/Itimg8.png')); ?>"  alt="">
        <img style="width: 600px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg9.png')); ?>"  alt="">
        <img style="width: 600px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg10.jpg')); ?>"  alt="">
       
    </section>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\ProyectoGeneral\resources\views/informacionTuristica.blade.php ENDPATH**/ ?>