<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Obtur-UTPL</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link href="">
        <!-- Styles -->   
        <style>
            body {
                font-family: 'Nunito';
            }
        </style>
        <link rel="stylesheet" href="css/estilos.css">
    </head>
    <body class="antialiased">
    <nav class="navbar navbar-expand-lg navbar-light bg-light"  style="background: linear-gradient(to bottom, yellow, white);">
        <div class="container" >
        <!--Menu de NAVEGACION -->
          <div class="row">
          
            <a class="navbar-brand" href="#">OBTUR-UTPL</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
              <div class="navbar-nav">
                <a class="nav-link active" aria-current="page" href="<?php echo e(url('welcome')); ?>">INICIO</a>
                <a class="nav-link" href="<?php echo e(url('obtur')); ?>">OBTUR</a>
                <a class="nav-link" href="#">INFORMACIÓN TURÍSTICA</a>
                <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">DATOS ESTADÍSTICOS</a>
                
              </div>
              </div>
            </div>
          </div>
        </div>
    </nav>
    <section>

</section>
    <?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
     integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<div class="container">
<!--inicia el slider-->
   
<div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel" >
  <ol class="carousel-indicators">
    <li data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active"></li>
    <li data-bs-target="#carouselExampleDark" data-bs-slide-to="1"></li>
    <li data-bs-target="#carouselExampleDark" data-bs-slide-to="2"></li>
  </ol>
 
  <div class="carousel-inner">
    <div class="carousel-item active" >
     <img src="<?php echo e(asset('imgs/mangahurco131.png')); ?>" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>First slide label</h5>
        <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
      </div>
    </div>
    <div class="carousel-item" >
    <img src="<?php echo e(asset('imgs/img4.jpeg')); ?>" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Second slide label</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      </div>
    </div>
    <div class="carousel-item">
    <img src="<?php echo e(asset('imgs/img5P.png')); ?>" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Third slide label</h5>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleDark" role="button" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleDark" role="button" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </a>
</div>
<h2>Descubre en la Provincia de Loja</h2>
<section class="sitios1" >
        <section class="img1">
            <img src="<?php echo e(asset('imgs/img1Hom.png')); ?>">
            
        </section>
        <h4>Eventos</h4>
</section >
<section class="sitios2" >
        <section>
            <img style="position: absolute; width: 590px; height: 333px; left: 722px; top: 870px;" src="<?php echo e(asset('imgs/img2Hom.png')); ?>">
        </section>
        <h4 style="position: absolute; width: 204px; height: 40px; left: 898px; top: 1220px; font-family: Quantico; font-style: normal; font-weight: normal; font-size: 30px; line-height: 43px; text-align: center; color: #FFFFFF;border: 1px solid #000000;">Plazas</h4>
</section >
<section class="sitios3" style="bakground:rgba(37, 239, 20, 0.7);position: absolute; width: 604px; height: 413px; left: 79px; top: 1353px;">
        <section>
            <img sty;e="position: absolute; width: 604px; height: 337px; left: 79px; top: 1351px;" src="<?php echo e(asset('imgs/img3Hom.png')); ?>">
        </section>
        <h4 style=" position: absolute; width: 287px; height: 55px; left: 245px; top: 1699px; font-family: Quantico; font-style: normal; font-weight: normal;
font-size: 30px; line-height: 43px; text-align: center;">Atractivos</h4>
</section >
<section class="sitios4" style="position: absolute; width: 591px; height: 413px; left: 721px; top: 1353px;
background: rgba(37, 239, 20, 0.7);">
        <section>
            <img style="position: absolute; width: 591px; height: 337px; left: 721px; top: 1353px;" src="<?php echo e(asset('imgs/img4Hom.png')); ?>">
        </section>
        <h4>Parques</h4>
</section>
</div>
  <script>
var myCarousel = document.querySelector('#myCarousel')
var carousel = new bootstrap.Carousel(myCarousel, {
  interval: 2000,
  wrap: false
})
</script>
   
<?php $__env->stopSection(); ?>

    </body>
</html>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apli\Laravel\proyectoObturC\resources\views/welcome.blade.php ENDPATH**/ ?>