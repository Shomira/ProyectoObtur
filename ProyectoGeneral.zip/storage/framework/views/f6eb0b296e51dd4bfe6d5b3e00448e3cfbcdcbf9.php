

<?php $__env->startSection('content'); ?>
    <h1 style="padding:0.2em 1em;">EQUIPO DE TRABAJO</h1>
    <img src="<?php echo e(asset('imgs/team.jpg')); ?>" class="imgTeam" alt="...">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\prueba\resources\views/obtur.blade.php ENDPATH**/ ?>