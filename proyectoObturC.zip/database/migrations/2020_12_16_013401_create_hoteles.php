<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHoteles extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hoteles', function (Blueprint $table) {
            $table->string('establecimiento');
            $table->string('clasificacion');
            $table->string('categoria');
            $table->integer('habitaciones');
            $table->integer('plazas');
            $table->string('fecha');
            $table->integer('checkins');
            $table->integer('checkout');
            $table->integer('pernotaciones');
            $table->integer('nacionales');
            $table->integer('extranjeros');
            $table->integer('habitaciones_ocupadas');
            $table->integer('habitaciones_disponibles');
            $table->string('tipo_tarifa');
            $table->double('tarifa_promedio');
            $table->double('TAR_PER');
            $table->double('ventas_netas');
            $table->string('porcentaje_ocupacion');
            $table->double('revpar');
            $table->integer('empleados_temporales');
            $table->string('estado');
            $table->string('opciones');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hoteles');
    }
}
