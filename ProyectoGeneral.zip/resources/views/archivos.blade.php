@extends('layouts.app')

@section('content')
<section class="fondo">
    <nav class="navAdmin">
        <a style="background-color: rgb(83, 50, 50)" href="{{url('archivos')}}">Cargar Datos</a>
        <a href="{{url('metricas')}}">Métricas</a>
        <a href="{{url('gestionUsuarios')}}">Gestionar Usuarios</a>
    </nav>

    <section class="espacioCA">
    <div class="card mt-4">
            <div class="card-header">
                Laravel Import Excel to database 
            </div>
                @if ($errors->any())
            <div class="alert alert-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
    @if($message = Session::get('success'))
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>{{ $message }}</strong>
    </div>
    @endif
            <div class="card-body">
                <form action="{{ url('import-excel') }}" method="POST" name="importform" enctype="multipart/form-data">
                    @csrf
                    <input type="file" name="import_file" class="form-control">
                    <br>
                    <button class="btn btn-success">Import File</button>
                </form>
            </div>
        </div>
    
    </section>

</section>

    
@endsection
