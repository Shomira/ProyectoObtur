<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Obtur-UTPL</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link href="">
        <!-- Styles -->   
        <style>
            body {
                font-family: 'Nunito';
            }
        </style>
        <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    </head>
    <body class="antialiased">
        
        <nav class="navbar navbar-expand-lg navbar-light bg-light"  style="background: linear-gradient(to bottom, yellow, white);">
            <div class="container" >
            <!--Menu de NAVEGACION -->
            <div class="row">
            
                <a class="navbar-brand" href="#">OBTUR-UTPL</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" aria-current="page" href="<?php echo e(url('welcome')); ?>">INICIO</a>
                        <a class="nav-link" href="<?php echo e(url('obtur')); ?>">OBTUR</a>
                        <a class="nav-link" href="<?php echo e(url('informacionTuristica')); ?>">INFORMACIÓN TURÍSTICA</a>
                        <a class="nav-link" href="<?php echo e(url('datosEstadisticos')); ?>" tabindex="-1" aria-disabled="true">DATOS ESTADÍSTICOS</a>
                    </div>
                </div>
            </div>
            </div>
            </div>
            
        </nav>
        <?php $__env->startSection('content'); ?>
<section class="portfolioInforTuris">
        <img style="left:60px; width: 548px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg1.png')); ?>"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg2.png')); ?>"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg3.png')); ?>"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg4.png')); ?>"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;"src="<?php echo e(asset('imgs/Itimag5.png')); ?>"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg6.png')); ?>"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;"src="<?php echo e(asset('imgs/Itimg7.png')); ?>"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;"src="<?php echo e(asset('imgs/Itimg8.png')); ?>"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;" src="<?php echo e(asset('imgs/Itimg9.png')); ?>"  alt="">
       
       
        </section>
        <?php $__env->stopSection(); ?>
    </body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apli\Laravel\proyectoObturC\resources\views/informacionTuristica.blade.php ENDPATH**/ ?>