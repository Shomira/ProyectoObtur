<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
/*Rutas de autentiacion */
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/obtur', function () {
    return view('obtur');
});
Route::get('/welcome', function () {
    return view('welcome');
});

Route::get('/datosEstadisticos', function () {
    return view('datosEstadisticos');
});
Route::get('/informacionTuristica', function () {
    return view('informacionTuristica');
});
/*Excel*/ 
Route::get('/import_excel', 'App\Http\Controllers\importExcelController@index');
Route::post('/import_excel/import', 'App\Http\Controllers\importExcelController@import');
Route::get('/import_excel', function () {
    return view('import_excel');
});
/*
Route::post('/import_excel/import', 'importExcelController@import');

Route::get('/import_excel', function () {
    return view('import_excel');
});
Route::get('/subir_archivo', function () {
    return view('subir_archivo');
});
*/