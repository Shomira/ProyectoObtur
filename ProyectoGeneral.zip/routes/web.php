<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/obtur', function () {
    return view('obtur');
});
Route::get('/welcome', function () {
    return view('welcome');
});

Route::get('/datosEstadisticos', function () {
    return view('datosEstadisticos');
});

Route::get('/informacionTuristica', function () {
    return view('informacionTuristica');
});

Route::get('/cargaDatos', function () {
    return view('cargaDatos');
});

Route::get('/metricas', function () {
    return view('metricas');
});

Route::get('/gestionUsuarios', function () {
    return view('gestionUsuarios');
});

Route::get('/archivos', 'App\Http\Controllers\ArchivoController@index');
Route::resource('/archivos', 'App\Http\Controllers\ArchivoController');

//Route::get('import-excel', 'App\Http\Controllers\ImportExcel\ImportExcelController@index');
Route::post('import-excel', 'App\Http\Controllers\ImportExcel\ImportExcelController@import');
