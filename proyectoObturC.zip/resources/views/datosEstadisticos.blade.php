<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Obtur-UTPL</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link href="">
        <!-- Styles -->   
        <style>
            body {
                font-family: 'Nunito';
            }
        </style>
        <link rel="stylesheet" href="{{ asset('css/estilos.css')}}">
    </head>
    <body class="antialiased">
        
        <nav class="navbar navbar-expand-lg navbar-light bg-light"  style="background: linear-gradient(to bottom, yellow, white);">
            <div class="container" >
            <!--Menu de NAVEGACION -->
            <div class="row">
            
                <a class="navbar-brand" href="#">OBTUR-UTPL</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" aria-current="page" href="{{url('welcome')}}">INICIO</a>
                        <a class="nav-link" href="{{url('obtur')}}">OBTUR</a>
                        <a class="nav-link" href="{{url('informacionTuristica')}}">INFORMACIÓN TURÍSTICA</a>
                        <a class="nav-link" href="{{url('datosEstadisticos')}}" tabindex="-1" aria-disabled="true">DATOS ESTADÍSTICOS</a>
                    </div>
                </div>
            </div>
            </div>
            </div>
            @extends('layouts.app')
        </nav>

        @section('content')

        <h2 class="tituloDatos">INDICADORES DE ALOJAMIENTO EN LOJA</h2>
        <section class="menu">

        </section>
        <section class="huespedes">
            <h2>Huéspedes</h2>
            <img src="{{ asset('imgs/Deimagen1.png')}}"  alt="">
            <img src="{{ asset('imgs/Deimagen2.png')}}"  alt="">
        </section>
        <section class=tarifaProm>
            <h2>Tarifa promedio</h2>
            <img style="width: 1000px;" src="{{ asset('imgs/Dehabita.PNG')}}"  alt="">
        </section>
        <section class= "indOcupacion">
            <h2>Indice de Ocupación</h2>
            <img  style="width: 1000px;" src="{{ asset('imgs/DePersona.PNG')}}"  alt="">
        </section>
        <section class="revpar">
            <h2>Revpar</h2>
            <img  style="width: 1000px;" src="{{ asset('imgs/DeRevpar.PNG')}}"  alt="">
        </section>
        @endsection
    </body>
</html>