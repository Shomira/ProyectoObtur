<?php

namespace App\Http\Controllers;

//use Facade\FlareClient\Stacktrace\File;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
//use App\File; 
use App\Models\File;

class ArchivoController extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       return view('archivos');


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        /*'file' =>'required|file|mimes:csv'
        $request->validate([
            'file' =>'required'
        ]);
        //request()->file('file')->getRealPath();
        $archivo = $request->file('file')->store('public');
        
        $url= Storage::url($archivo);
        File::create([
                'url' => $url
        ]);
            
        //return redirect()->route('archivos.index')->with("success", __("Archivo subido correctamente!"))->store("public");
        return redirect(route("archivos.index"))->with("success", __("Archivo subido correctamente!"));*/
        $request->validate([
            'file' =>'required|mimetypes:text/csv,text/plain,application/csv,text/comma-separated-values'
        ]);
        $nombre = Str::random(10) . $request->file('file')->getClientOriginalName();

        //guarda el archivo en la carpeta /sotre/public
        $request->file('file')->storeAs('public',$nombre);
        //Storage::putFileAs($nombre,$request->file('file')->store('public'));

        File::create([
            'user_id' => auth()->user()->id,
            'url' => 'storage/' . $nombre
        ]);
        
      
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($file)
    {
        return view('show');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($file)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $file)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($file)
    {
        //
    }
}
