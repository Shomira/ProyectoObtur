<!DOCTYPE html>
<html>
 <head>
  <title>Import Excel File in Laravel</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 </head>
 <body>
  <br />
  <?php if(count($errors)>0): ?>

  <div class="alert alert-danger">
  Upload  validation Error<br><br>
  <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li> <?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  </div>
  $endif
  $if(message =Session::get('success'))
  <div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>
           <strong><?php echo e($message); ?></strong>
   </div>
   <?php endif; ?>
  <div class="container">
   <h3 style="align='center'">Import Excel File in Laravel</h3>
    <br />
    <form action="<?php echo e(url('/imprt_excel/import')); ?>" method="post"  enctype="multipart/form-data"></form>
   <?php echo e(csrf_field()); ?>

   <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
     Upload Validation Error<br><br>
     <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
    </div>
   <?php endif; ?>

   <?php if($message = Session::get('success')): ?>
   <div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>
           <strong><?php echo e($message); ?></strong>
   </div>
   <?php endif; ?>
   <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/import_excel/import')); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
     <table class="table">
      <tr>
       <td width="40%" style="align='center'"><label>Select File for Upload</label></td>
       <td width="30">
        <input type="file" name="select_file" />
       </td>
       <td width="30%" style="align='left'">
        <input type="submit" name="upload" class="btn btn-primary" value="Upload">
       </td>
      </tr>
      <tr>
       <td width="40%" style="align='right'"></td>
       <td width="30"><span class="text-muted">.xls, .xslx</span></td>
       <td width="30%" style="align='left'"></td>
      </tr>
     </table>
    </div>
   </form>
   
   <br />
   <div class="panel panel-default">
    <div class="panel-heading">
     <h3 class="panel-title">Customer Data</h3>
    </div>
    <div class="panel-body">
     <div class="table-responsive">
      <table class="table table-bordered table-striped">
       <tr>
        <th>Establecimiento</th>
        <th>Clasificacion</th>
        <th>Categoria</th>
        <th>Habitaciones</th>
        <th>Plazas</th>
        <th>fecha</th>
        <th>checkins</th>
        <th>checkout</th>
        <th>pernotaciones</th>
        <th>nacionales</th>
        <th>extranjeros</th>
        <th>habitaciones_ocuapdas</th>
        <th>habitaciones_disponibles</th>
        <th>tipo_tarifa</th>
        <th>tarifa_promedio</th>
        <th>TAR_PER</th>
        <th>ventas_netas</th>
        <th>porcentaje_ocupacion</th>
        <th>revpar</th>
        <th>empleados_temporales</th>
        <th>estado</th>
        <th>opciones</th>
       </tr>
       <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       <td><?php echo e($row->establecimiento); ?></td>
        <td><?php echo e($row->clasificacion); ?></td>
        <td><?php echo e($row->categoria); ?></td>
        <td><?php echo e($row->habitaciones); ?></td>
        <td><?php echo e($row->fecha); ?></td>
        <td><?php echo e($row->checkins); ?></td>
        <td><?php echo e($row->checkout); ?></td>
        <td><?php echo e($row->pernotaciones); ?></td>
        <td><?php echo e($row->nacionales); ?></td>
        <td><?php echo e($row->extranjeros); ?></td>
        <td><?php echo e($row->habitaciones_ocuapdas); ?></td>
        <td><?php echo e($row->habitaciones_disponibles); ?></td>
        <td><?php echo e($row->tipo_tarifa); ?></td>
        <td><?php echo e($row->tarifa_promedio); ?></td>
        <td><?php echo e($row->TAR_PER); ?></td>
        <td><?php echo e($row->ventas_netas); ?></td>
        <td><?php echo e($row->porcentaje_ocupacion); ?></td>
        <td><?php echo e($row->revpar); ?></td>
        <td><?php echo e($row->empleados_temporales); ?></td>
        <td><?php echo e($row->estado); ?></td>
        <td><?php echo e($row->opciones); ?></td>
       </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
     </div>
    </div>
   </div>
  </div>
 </body>
</html><?php /**PATH C:\xampp\htdocs\apli\Laravel\proyectoObturC\resources\views/import_excel.blade.php ENDPATH**/ ?>