

<?php $__env->startSection('content'); ?>
<section class="fondo">
    <nav class="navAdmin">
        <a href="<?php echo e(url('archivos')); ?>">Cargar Datos</a>
        <a href="<?php echo e(url('metricas')); ?>">Métricas</a>
        <a style="background-color: rgb(83, 50, 50)" href="<?php echo e(url('gestionUsuarios')); ?>">Gestionar Usuarios</a>
    </nav>
    
    <section class="espacio">

    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\ProyectoGeneral\resources\views/gestionUsuarios.blade.php ENDPATH**/ ?>