@extends('layouts.app')

@section('content')
<section class="fondo">
    <nav class="navAdmin">
        <a href="{{url('cargaDatos')}}">Cargar Datos</a>
        <a style="background-color: rgb(83, 50, 50)" href="{{url('metricas')}}">Métricas</a>
        <a href="{{url('gestionUsuarios')}}">Gestionar Usuarios</a>
    </nav>
    
    <section class="espacio">

    </section>
</section>
@endsection