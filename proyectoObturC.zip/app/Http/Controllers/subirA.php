<?php
$dir ='../upload';

foreach($_FILES as $key)