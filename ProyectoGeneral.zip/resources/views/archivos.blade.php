@extends('layouts.app')

@section('content')
<section class="fondo">
    <nav class="navAdmin">
        <a style="background-color: rgb(83, 50, 50)" href="{{url('archivos')}}">Cargar Datos</a>
        <a href="{{url('metricas')}}">Métricas</a>
        <a href="{{url('gestionUsuarios')}}">Gestionar Usuarios</a>
    </nav>

    <section class="espacioCA">
    <div class="container">
        <div class="row">
            <div class="col">
                <h1>Subir Archivos</h1>
                <form action="{{ route('archivos.store')}}" method="POST"
                class="dropzone"
                id="my-awesome-dropzone"></form>
                 {{--<div class="card">
                    <div class="card-body">
                        {{route('admin.files.store')}}
                        archvivos.store
                        accept='.csv'
                        <form action="{{ route('archivos.store')}}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group">
                                <input type="file" name="file" id="" accept=".csv">
                                @error('file')
                                <small class="text-danger"><br>{{$message}}</small>
                                @enderror
                            </div>
                            <button type="submit" class="btn btn-primary">Subir Archivo</button>
                        </form>
        
                    </div>--}}
                </div>
             </div>
        </div>
    </div>
    </section>

    


</section>

    
@endsection

@section('js')

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.2/min/dropzone.min.js"></script>
    <script>
        Dropzone.options.myAwesomeDropzone = {
            
            headers:{
                'X-CSRF-TOKEN' : "{{csrf_token()}}"
            },
            dictDefaultMessage: "Arrastre un archivo al recuadro para subirlo",
            acceptedFiles: ".csv",
            maxFiles: 4,
            init: function() {
                this.on("success", function(file) { alert("Archivo/s subido/s exitosamente"); });
            }
        };
    </script>
@endsection