<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/prueba', function () {
    return view('prueba');
});

Route::get('/import_excel', 'importExcelController@index');
Route::post('/import_excel/import', 'importExcelController@import');
Route::get('/import_excel', function () {
    return view('import_excel');
});
/*
Route::get('/subir_archivo', function () {
    return view('subir_archivo');
});
*/