<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
     integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
     <link rel="stylesheet" href="{{ asset('css/estilos.css')}}">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light"  style="background: linear-gradient(to bottom, yellow, white);">
  <div class="container" >
  <!--Menu de NAVEGACION -->
    <div class="row">
      <a class="navbar-brand" href="#">OBTUR-UTPL</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link active" aria-current="page" href="{{url('welcome')}}">INICIO</a>
          <a class="nav-link" href="#">OBTUR</a>
          <a class="nav-link" href="{{url('informacionTuristica')}}">INFORMACIÓN TURÍSTICA</a>
          <a class="nav-link " href="{{url('datosEstadisticos')}}" tabindex="-1" aria-disabled="true">DATOS ESTADÍSTICOS</a>
        </div>
        </div>
      </div>
    </div>
  </div>
</nav>
<h1 style="padding:0.2em 1em;">EQUIPO DE TRABAJO</h1>
 <img src="{{ asset('imgs/team.jpg')}}" class="imgTeam" alt="...">


</html>
