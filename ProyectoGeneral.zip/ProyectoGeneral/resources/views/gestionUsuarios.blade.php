@extends('layouts.app')

@section('content')
<section class="fondo">
    <nav class="navAdmin">
        <a href="{{url('cargaDatos')}}">Cargar Datos</a>
        <a href="{{url('metricas')}}">Métricas</a>
        <a style="background-color: rgb(83, 50, 50)" href="{{url('gestionUsuarios')}}">Gestionar Usuarios</a>
    </nav>
    
    <section class="espacio">

    </section>
</section>
@endsection
