@extends('layouts.app')

@section('content')
    <h1 style="padding:0.2em 1em;">EQUIPO DE TRABAJO</h1>
    <img src="{{ asset('imgs/team.jpg')}}" class="imgTeam" alt="...">

@endsection