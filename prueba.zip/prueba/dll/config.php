<?php 
    $site_url="http://127.0.0.1/ingenieriaWeb/prueba/";
    $local_path="C:\\xampp\htdocs\ingenieriaWeb\prueba";
	//datos de la base de datos
	define('DBHOST', '127.0.0.1');
	define('DBUSER', 'root');
	define('DBPASS', '');
	define('DBNAME', 'proyectoobtur');
?>