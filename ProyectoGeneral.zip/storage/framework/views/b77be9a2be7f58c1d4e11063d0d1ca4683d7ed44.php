

<?php $__env->startSection('content'); ?>
<section class="fondo">
    <nav class="navAdmin">
        <a style="background-color: rgb(83, 50, 50)" href="<?php echo e(url('cargaDatos')); ?>">Cargar Datos</a>
        <a href="<?php echo e(url('metricas')); ?>">Métricas</a>
        <a href="<?php echo e(url('gestionUsuarios')); ?>">Gestionar Usuarios</a>
    </nav>

    <section class="espacio">

    </section>

    <div class="container">
        <div class="row">
            <div class="col">
                <h1>Subir Archivos</h1>
                <form action="<?php echo e(route('cargaDatos.store')); ?>" method="POST"
                class="dropzone"
                id="my-awesome-dropzone"></form>
                 
                </div>
             </div>
        </div>
    </div>



</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<h2>hola</h2>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.2/min/dropzone.min.js"></script>
    <script>
        Dropzone.options.myAwesomeDropzone = {
            
            headers:{
                'X-CSRF-TOKEN' : "<?php echo e(csrf_token()); ?>"
            },
            dictDefaultMessage: "Arrastre un archivo al recuadro para subirlo",
            acceptedFiles: ".csv",
            maxFiles: 4,
            init: function() {
                this.on("success", function(file) { alert("Archivo/s subido/s exitosamente"); });
            }
        };
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\ProyectoGeneral\resources\views/cargaDatos.blade.php ENDPATH**/ ?>