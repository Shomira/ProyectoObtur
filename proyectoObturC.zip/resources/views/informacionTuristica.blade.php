<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Obtur-UTPL</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link href="">
        <!-- Styles -->   
        <style>
            body {
                font-family: 'Nunito';
            }
        </style>
        <link rel="stylesheet" href="{{ asset('css/estilos.css')}}">
    </head>
    <body class="antialiased">
        
        <nav class="navbar navbar-expand-lg navbar-light bg-light"  style="background: linear-gradient(to bottom, yellow, white);">
            <div class="container" >
            <!--Menu de NAVEGACION -->
            <div class="row">
            
                <a class="navbar-brand" href="#">OBTUR-UTPL</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" aria-current="page" href="{{url('welcome')}}">INICIO</a>
                        <a class="nav-link" href="{{url('obtur')}}">OBTUR</a>
                        <a class="nav-link" href="{{url('informacionTuristica')}}">INFORMACIÓN TURÍSTICA</a>
                        <a class="nav-link" href="{{url('datosEstadisticos')}}" tabindex="-1" aria-disabled="true">DATOS ESTADÍSTICOS</a>
                    </div>
                </div>
            </div>
            </div>
            </div>
            @extends('layouts.app')
        </nav>
        @section('content')
<section class="portfolioInforTuris">
        <img style="left:60px; width: 548px; height: 326px; object-fit: cover;" src="{{ asset('imgs/Itimg1.png')}}"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;" src="{{ asset('imgs/Itimg2.png')}}"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;" src="{{ asset('imgs/Itimg3.png')}}"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;" src="{{ asset('imgs/Itimg4.png')}}"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;"src="{{ asset('imgs/Itimag5.png')}}"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;" src="{{ asset('imgs/Itimg6.png')}}"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;"src="{{ asset('imgs/Itimg7.png')}}"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;"src="{{ asset('imgs/Itimg8.png')}}"  alt="">
        <img style="width: 548px; height: 326px; object-fit: cover;" src="{{ asset('imgs/Itimg9.png')}}"  alt="">
       
       
        </section>
        @endsection
    </body>
</html>