<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
Use Excel;

class importExcelController extends Controller
{
    //
    function index()
        {
            $data = DB::table('hoteles')->orderBy('habitaciones','DESC')
                 ->get();
            return view('import_excel', compact('data'));
        }
    function import(Request $request)
    {
        $this->validate($request, [
            'select_file' => 'requiered|mimes:xls,xls'

        ]);
        $path = $request->file('select_file')->getPath();
            $data =Excel::load($path)->get();
            if($data->count()>0){
                foreach($data->toArray() as $key => $value)
                {
                    foreach($value as $row)
                    {
                        $insert_data[]=array(
                            'establecimiento' => $row['establecimiento'],
                            'clasificacion'=>  $row['clasificacion'],
                            'categoria'=>    $row['categoria'],
                            'habitaciones'=>     $row['habitaciones'],
                              'fecha'=>      $row['fecha'],
                              'checkins'=>         $row['checkins'],
                              'checkout'=>    $row['checkout'],
                              'pernotaciones'=>   $row['pernotaciones'],
                              'nacionales'=>     $row['nacionales'],
                              'extranjeros'=>   $row['extranjeros'],
                              'habitaciones_ocuapdas'=>      $row['habitaciones_ocuapdas'],
                              'habitaciones_disponibles'=>    $row['habitaciones_disponibles'],
                              'tipo_tarifa'=>  $row['tipo_tarifa'],
                              'tarifa_promedio'=>  $row['tarifa_promedio'],
                              'TAR_PER'=>  $row['TAR_PER'],
                              'ventas_netas'=>  $row['ventas_netas'],
                              'porcentaje_ocupacion'=>   $row['porcentaje_ocupacion'],
                              'revpar'=> $row['revpar'],
                              'empleados_temporales'=>     $row['empleados_temporales'],
                              'estado'=>  $row['estado'],
                              'opciones'=>  $row['opciones']
                        );
                        if(!empty($insert_data))
                        {
                            DB::table('hoteles')->insert($insert_data);
                        }
                    }
                    return back()-with('success', 'Excel Data impoted successfully.');
                }
            }
    }
}
